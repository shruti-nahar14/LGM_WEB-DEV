import React from 'react'

const Footer = () => {
  return (
    <footer className='center'>
      <br/>
        <span>Created By <a href='#'>_____________</a></span>
    </footer>
  )
}

export default Footer
